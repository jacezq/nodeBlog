/**
 * Created by jace on 2016/12/6.
 */
var mongoose = require('mongoose');

module.exports = new mongoose.Schema({

//    分类名称
    name:String
});